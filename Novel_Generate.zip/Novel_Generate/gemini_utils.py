# gemini_utils.py
"""
本模块提供与 Google Gemini 模型交互的实用函数。

提供的函数：
    - generate_text(input_text, model_name="gemini-2.0-flash") -> Optional[str]
        单轮生成请求：发送输入文本给模型，并返回生成的文本。
        重试过程中采用 300s 重试计时器，若在该时间内未获得正确返回，则返回超时信息。

    - generate_answers(questions, n=1, model_name="gemini-2.0-flash") -> str
        多轮对话请求：在单个会话中依次发送所有问题，
        保存每轮生成的回答以共享上下文信息。
        当任一对话失败或会话丢失时，将刷新 API key 并重新建立会话，
        从第一个问题开始重新尝试。单个会话中采用 300s 重试计时器，
        每轮成功回答后重置计时器；因会话丢失的重试次数上限为 5 次，
        每次会话丢失时也会刷新计时器。
"""

from google import genai
import time
import os
import random
from typing import List, Optional

def load_api_keys(filepath="APIKEYS.txt") -> List[str]:
    """
    从指定文件中加载 API keys，每行一个 key。

    参数:
        filepath: 存储 API keys 的文件路径，默认为 "APIKEYS.txt"。

    返回:
        包含所有有效 API keys 的列表。
        如果文件不存在或没有有效 key，则返回空列表。
    """
    api_keys = []
    try:
        with open(filepath, 'r') as f:
            for line in f:
                key = line.strip()
                if key:  # 忽略空行
                    api_keys.append(key)
    except FileNotFoundError:
        print(f"警告: API keys 文件 '{filepath}' 未找到。")
    return api_keys

# 加载 API keys，若无有效 key，则终止程序
API_KEYS = load_api_keys()
if not API_KEYS:
    raise ValueError("APIKEYS.txt 文件中没有有效的 API keys，请检查文件内容。")

def generate_text(input_text: str, model_name: str = "gemini-2.0-flash") -> Optional[str]:
    """
    单轮生成请求：发送输入文本给模型，并返回生成的文本。

    当一次请求失败时，启动重试计时器（300s），在计时器内不断重试，
    若超过 300s 仍未成功则返回 "超时，生成失败"。

    参数:
        input_text: 用户输入的文本。
        model_name: 使用的模型名称，默认为 "gemini-2.0-flash"。

    返回:
        成功时返回模型生成的文本；如果超时则返回 "超时，生成失败"。
    """
    # 初始化计时器
    last_success_time = time.time()
    timeout_duration = 300  # 300 秒超时

    while True:
        # 检查自上次成功后的等待时间是否超过阈值
        if time.time() - last_success_time > timeout_duration:
            return "超时，生成失败"

        # 随机选择一个 API key
        api_key = random.choice(API_KEYS)
        try:
            client = genai.Client(api_key=api_key)
            response = client.models.generate_content(
                model=model_name,
                contents=input_text
            )
            # 请求成功时重置计时器（虽然此处直接返回结果）
            last_success_time = time.time()
            return response.text
        except Exception as e:
            wait_seconds = random.randint(4, 12)
            print(f"请求失败, 错误: {e}。等待 {wait_seconds} 秒后使用新的 API key 重试...")
            time.sleep(wait_seconds)

def generate_answers(questions: List[str], n: int = 1, model_name: str = "gemini-2.0-flash") -> str:
    """
    多轮对话请求：在单个会话中依次发送所有问题，
    并保存每轮生成的回答以共享上下文信息。

    当任一对话失败或因会话丢失需要重新建立会话时，
    将刷新 API key 并从第一个问题开始重新尝试。
    单个会话中采用 300s 重试计时器，且每轮成功回答后计时器会重置；
    因会话丢失的重试次数上限为 5，若超过该次数或重试过程中单个会话超时，则返回 "超时，生成失败"。

    参数:
        questions: 字符串列表，每个元素为一轮对话的用户问题。
        n: 返回结果中保留最后 n 个回答，默认为 1（n 不超过问题总数）。
        model_name: 使用的模型名称，默认为 "gemini-2.0-flash"。

    返回:
        成功时返回最后 n 个回答（以 "===\n" 分隔）的组合字符串；
        若超时或重试上限达到，则返回 "超时，生成失败"。
    """
    if not questions:
        return ""
    
    # 确保 n 在合法范围内，不超过问题数
    n = max(1, min(n, len(questions)))
    max_attempts = 5  # 会话丢失重试次数上限
    attempt_count = 0

    # 每次新会话时重置计时器
    while attempt_count < max_attempts:
        attempt_count += 1
        session_start = time.time()  # 新会话计时器
        try:
            api_key = random.choice(API_KEYS)
            client = genai.Client(api_key=api_key)
            chat = client.chats.create(model=model_name)
            responses: List[str] = []
            
            for question in questions:
                # 检查单个会话内是否超过 300s 超时限制
                if time.time() - session_start > 300:
                    raise TimeoutError("单会话超时")
                response = chat.send_message(message=question)
                responses.append(response.text)
                # 每轮成功后重置计时器
                session_start = time.time()
            
            return "\n---\n".join(responses[-n:])
        except Exception as e:
            wait_seconds = random.randint(4, 12)
            print(f"会话尝试 {attempt_count} 失败，错误: {e}。等待 {wait_seconds} 秒后重试...")
            time.sleep(wait_seconds)
            # 重试时将建立新会话并重置计时器

    return "超时，生成失败"
