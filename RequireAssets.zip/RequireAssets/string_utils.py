# string_utils.py
"""
本模块提供字符串和文件操作的实用函数。

函数：
    file_to_string(file_path, isblock=False) -> str:
        读取文件内容为字符串。
        参数: file_path (文件路径), isblock (是否用```包裹，可选)。
        返回: 文件内容的字符串形式。
        
    string_to_file(content, file_path) -> None:
        将字符串写入文件 (覆盖或创建)。
        参数: content (要写入的内容), file_path (文件路径)。
        返回: 无。
        
    replaceStringSymbol(input_str, placeholder, replacement) -> str:
        替换字符串中的占位符。
        参数: input_str (输入字符串), placeholder (占位符), replacement (替换值)。
        返回: 替换后的字符串。
        
    combine_strings(*strings) -> str:
        用换行符连接多个字符串。
        参数: *strings (可变数量的字符串)。
        返回: 连接后的字符串。
        
    extract_code_blocks(text, n=1, isblock=False) -> str:
        提取文本中的最后n个代码块 (```包围)。
        参数: text (输入文本), n (提取数量，可选), isblock (是否用```包裹，可选)。
        返回: 提取的代码块字符串 (用"---"分隔)。

更详细的参数、返回值和错误处理信息，请参阅各函数的文档字符串。
"""

import os
import re

# 文件转字符串函数
def file_to_string(file_path, isblock=False):
    """
    读取文件内容并返回。可以选择是否用 ``` 包裹返回。

    Args:
        file_path: 文件路径。
        isblock: 布尔值，默认为 False。如果为 True，则返回的内容用 ``` 包裹。

    Returns:
        一个字符串，包含文件内容，可以选择是否用 ``` 包裹。
    """
    try:
        with open(file_path, 'r', encoding='utf-8') as f:
            content = f.read()
        if isblock:
            return f"```\n{content}\n```"
        else:
            return content
    except FileNotFoundError:
        return f"Error: File not found at {file_path}"
    except Exception as e:
        return f"Error: An unexpected error occurred: {e}"

# 字符串转文件函数
def string_to_file(content, file_path):
    """
    将字符串内容写入文件，如果文件存在则覆盖，不存在则创建。

    Args:
        content: 要写入文件的字符串内容。
        file_path: 目标文件路径。
    """
    try:
        # 直接使用 'w' 模式打开文件，如果存在则覆盖，不存在则创建
        with open(file_path, 'w', encoding='utf-8') as f:
            f.write(content)
        print(f"Successfully wrote content to: {file_path}")
    except Exception as e:
        print(f"Error: An error occurred: {e}")


# 字符串动态修改函数
def replaceStringSymbol(input_str: str, placeholder: str, replacement: str) -> str:
    """
    将输入字符串中的占位符替换为指定的内容。

    :param input_str: 输入的字符串
    :param placeholder: 占位符字符串
    :param replacement: 用于替换占位符的字符串
    :return: 替换占位符后的新字符串
    """
    return input_str.replace(placeholder, replacement)

# 字符串换行合并函数
def combine_strings(*strings):
  """
  接受至少一个参数的字符串，并逐个按照顺序使用 \\n 连接之后，返回该字符串。

  Args:
    *strings: 可变参数，表示要连接的字符串。至少需要一个字符串。

  Returns:
    连接后的字符串，使用 \\n 分隔。
    如果没有任何输入字符串，则返回空字符串。

  Raises:
    TypeError: 如果输入的不是字符串。
  """
  if not strings:
    return ""
  
  for s in strings:
     if not isinstance(s,str):
       raise TypeError("All arguments must be strings.")

  return "\n".join(strings)

# 代码块提取函数
def extract_code_blocks(text, n=1, isblock=False):
    """
    从文本中提取倒数第 n 到第 1 个代码块的内容，忽略代码块注解。

    Args:
        text: 包含代码块的文本。
        n: 要提取的倒数第 n 个代码块，默认为 1。
        isblock: 是否将返回的内容用代码块包裹，默认为 False。

    Returns:
        提取的代码块内容，以换行符连接，如果 isblock 为 True，则用代码块包裹。
    """
    lines = text.splitlines()
    code_blocks = []
    in_code_block = False
    current_block = []

    for line in lines:
        if line.strip().startswith("```"):  # 查找代码块起始行
            if not in_code_block:
                in_code_block = True
                current_block = []  # 清空当前代码块
            else:
                in_code_block = False
                code_blocks.append("\n".join(current_block))
        elif in_code_block:
            current_block.append(line)
            
    max_blocks = len(code_blocks)
    if max_blocks == 0:
       return ""

    n = max(1, min(n, max_blocks))
    start_index = max_blocks - n
    end_index = max_blocks
    extracted_blocks = code_blocks[start_index:end_index]
    concatenated_content = "\n\n===\n\n".join(block.strip() for block in extracted_blocks)

    if isblock:
        return f"```\n{concatenated_content}\n```"
    else:
        return concatenated_content